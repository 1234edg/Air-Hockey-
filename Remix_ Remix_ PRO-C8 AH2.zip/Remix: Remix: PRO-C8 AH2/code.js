var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var wall1=createSprite(10,200,5,375);
wall1.shapeColor="red";

var wall2=createSprite(397,200,5,800);
wall2.shapeColor="red";

var wall3=createSprite(390,200,5,375);
wall3.shapeColor="red";

var wall4=createSprite(3,10,5,800);
wall4.shapeColor="red";

var wall5=createSprite(200,10,385,5);
wall5.shapeColor="red";

var wall6=createSprite(200,4,400,5);
wall6.shapeColor="red";

var wall7=createSprite(200,390,385,5);
wall7.shapeColor="red";

var wall8=createSprite(200,396,400,5);
wall8.shapeColor="red";

var goal1=createSprite(200,38,100,20);
goal1.shapeColor="yellow";

var goal2=createSprite(200,372,100,20);
goal2.shapeColor="yellow";

var striker=createSprite(200,200,10,10);
striker.shapeColor="blue";

var playermallet=createSprite(200,60,50,10);
playermallet.shapeColor="black";

var compmallet=createSprite(200,350,50,10);
compmallet.shapeColor="black";
 //variable to store different state of game
var gameState = "serve";
var playerscore=0; 


var playerscore=0; 
var compscore=0;
function draw() {
  background("white");
  
 //place info text in the center
  if (gameState === "serve") {
    text("Press Space to Serve",150,180);
    text.shapeColor="white";
  }
  textSize(9)
  stroke("red");
  text (playerscore,50,190);
  textSize(9)
  text (compscore,50,220);
  
  
//draw line at the centre
  for (var i = 0; i < 400; i=i+20) {
    line(i,200,i+10,200);
    
  }
  
  createEdgeSprites();
   //create edge boundaries
  //make the ball bounce with the top and the bottom edges
  createEdgeSprites();
  striker.bounceOff(topEdge);
  striker.bounceOff(bottomEdge);
  striker.bounceOff(wall1);
  striker.bounceOff(wall2);
  striker.bounceOff(playermallet);
  striker.bounceOff(compmallet);
  compmallet.bounceOff(edges);
  playermallet.bounceOff(edges);
  compmallet.bounceOff(wall3);
  playermallet.bounceOff(wall3);
  compmallet.bounceOff(wall4);
  playermallet.bounceOff(wall4);
  compmallet.bounceOff(wall5);
  playermallet.bounceOff(wall5);
  compmallet.bounceOff(wall6);
  playermallet.bounceOff(wall6);
  compmallet.bounceOff(wall7);
  playermallet.bounceOff(wall7);
  compmallet.bounceOff(wall8);
  playermallet.bounceOff(wall8);
  compmallet.bounceOff(wall1);
  playermallet.bounceOff(wall1);
  compmallet.bounceOff(wall2);
  playermallet.bounceOff(wall2);
  
 if (keyDown("LEFT_ARROW")) {
  playermallet.x=playermallet.x-10;
}
if (keyDown("RIGHT_ARROW")) {
  playermallet.x=playermallet.x+10;
}
if (keyDown("UP_ARROW")) {
  playermallet.x=playermallet.x-10;
}
if (keyDown("DOWN_ARROW")) {
  playermallet.x=playermallet.x-10;
}
compmallet.x=striker.x; 
  
 if(compscore===5|| playerscore===5){
   gameState="game over";
   text("Press 'R' To restart",150,180);
   text("GAME OVER",162,150);
   
 } 
 if(keyDown("r")&& gameState==="game over"){
 gameState="serve";
 playerscore=0;
 compscore=0;   
 
 }
  
  //serve the ball when space is pressed
  if (keyDown("space") && gameState === "serve") {
    serve();
    gameState = "play";
  
  }
  
  
  //score
  if(striker.isTouching(goal1) || striker.isTouching(goal2)) {

    if(striker.isTouching(goal1)){
    compscore=compscore+1;    
    }
     if(striker.isTouching(goal2)){
    playerscore=playerscore+1;    
    }
    
    

  reset();
  gameState = "serve";
  
  }
  drawSprites();
}
  
  function serve() {
  striker.velocityX = 6;
  striker.velocityY = 8;
}

function reset() {
  striker.x = 200;
  striker.y = 200;
  striker.velocityX = 0;
  striker.velocityY = 0;
}
  


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
